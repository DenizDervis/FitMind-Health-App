import UIKit

class SignUpViewController: UIViewController {
    
    let nameField = UITextField()
    let emailField = UITextField()
    let passwordField = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupSignUpForm()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.orange.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupSignUpForm() {
        nameField.placeholder = "Name"
        nameField.borderStyle = .roundedRect
        emailField.placeholder = "Email"
        emailField.borderStyle = .roundedRect
        emailField.autocapitalizationType = .none
        passwordField.placeholder = "Password"
        passwordField.borderStyle = .roundedRect
        passwordField.isSecureTextEntry = true
        
        let signUpButton = UIButton(type: .system)
        signUpButton.setTitle("Sign Up", for: .normal)
        signUpButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        signUpButton.setTitleColor(.white, for: .normal)
        signUpButton.backgroundColor = .orange
        signUpButton.layer.cornerRadius = 10
        signUpButton.translatesAutoresizingMaskIntoConstraints = false
        signUpButton.addTarget(self, action: #selector(handleSignUp), for: .touchUpInside)
        
        let stackView = UIStackView(arrangedSubviews: [nameField, emailField, passwordField, signUpButton])
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            nameField.heightAnchor.constraint(equalToConstant: 50),
            emailField.heightAnchor.constraint(equalToConstant: 50),
            passwordField.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc func handleSignUp() {
        guard let email = emailField.text, let password = passwordField.text, let name = nameField.text,
              !email.isEmpty, !password.isEmpty, !name.isEmpty else {
            showErrorMessage("Please fill all fields.")
            return
        }
        
        // Save the user's credentials and name
        UserDefaults.standard.set(password, forKey: "userPassword_\(email)")
        UserDefaults.standard.set(name, forKey: "userName_\(email)")
        
        // Store the currently signed-up user as the current user
        UserDefaults.standard.set(email, forKey: "currentUserEmail")
        UserDefaults.standard.set(name, forKey: "currentUserName")
        
        // Navigate to the main view controller after successful sign up
        let mainVC = ViewController()
        let navigationController = UINavigationController(rootViewController: mainVC)
        
        if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate {
            sceneDelegate.window?.rootViewController = navigationController
        }
    }

    
    func showErrorMessage(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
