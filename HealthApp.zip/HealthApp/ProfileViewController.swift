import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    let profileImageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupBackground()
        setupProfileInfo()
        setupLogoutButton()
        setupProfilePictureButton()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.orange.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    func setupProfileInfo() {
        // Add the profileImageView to the view hierarchy before applying constraints
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(profileImageView)
        
        // Load the profile image from UserDefaults if it exists
        if let imageData = UserDefaults.standard.data(forKey: "profileImage_\(UserDefaults.standard.string(forKey: "currentUserEmail") ?? "")") {
            profileImageView.image = UIImage(data: imageData)
        } else {
            profileImageView.image = UIImage(systemName: "person.circle.fill")
            profileImageView.tintColor = .white
        }

        // Fetch the current user's name and email from UserDefaults
        let userName = UserDefaults.standard.string(forKey: "currentUserName") ?? "Unknown User"
        let userEmail = UserDefaults.standard.string(forKey: "currentUserEmail") ?? "unknown@example.com"
        
        // Name Label
        let nameLabel = UILabel()
        nameLabel.text = "Name: \(userName)"
        nameLabel.textColor = .white
        nameLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        // Email Label
        let emailLabel = UILabel()
        emailLabel.text = "Email: \(userEmail)"
        emailLabel.textColor = .white
        emailLabel.font = UIFont.systemFont(ofSize: 18)
        emailLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emailLabel)
        
        NSLayoutConstraint.activate([
            profileImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80), // Adjusted from 40
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 150),
            profileImageView.heightAnchor.constraint(equalToConstant: 150),
            
            nameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 40),  // Adjusted from 30
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            emailLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 16),
            emailLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

    }

    func setupLogoutButton() {
        let logoutButton = UIButton(type: .system)
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        logoutButton.setTitleColor(.white, for: .normal)
        logoutButton.backgroundColor = .red
        logoutButton.layer.cornerRadius = 10
        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        logoutButton.addTarget(self, action: #selector(handleLogout), for: .touchUpInside)
        
        view.addSubview(logoutButton)
        
        NSLayoutConstraint.activate([
            logoutButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -40),
            logoutButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logoutButton.widthAnchor.constraint(equalToConstant: 200),
            logoutButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    func setupProfilePictureButton() {
        let uploadImageButton = UIButton(type: .system)
        uploadImageButton.setTitle("Change Profile Picture", for: .normal)
        uploadImageButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        uploadImageButton.setTitleColor(.white, for: .normal)
        uploadImageButton.backgroundColor = .orange
        uploadImageButton.layer.cornerRadius = 10
        uploadImageButton.translatesAutoresizingMaskIntoConstraints = false
        uploadImageButton.addTarget(self, action: #selector(handleChangeProfilePicture), for: .touchUpInside)
        
        view.addSubview(uploadImageButton)
        
        NSLayoutConstraint.activate([
            uploadImageButton.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 20),
            uploadImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            uploadImageButton.widthAnchor.constraint(equalToConstant: 200),
            uploadImageButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc func handleChangeProfilePicture() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[.originalImage] as? UIImage {
            profileImageView.image = pickedImage
            
            // Save profile image to UserDefaults
            if let imageData = pickedImage.jpegData(compressionQuality: 0.8) {
                UserDefaults.standard.set(imageData, forKey: "profileImage_\(UserDefaults.standard.string(forKey: "currentUserEmail") ?? "")")
            }
        }
        dismiss(animated: true, completion: nil)
    }
    
    @objc func handleLogout() {
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        
        let loginVC = LoginViewController()
        let navigationController = UINavigationController(rootViewController: loginVC)
        
        if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate {
            sceneDelegate.window?.rootViewController = navigationController
        }
    }
}
