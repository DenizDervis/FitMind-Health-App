import UIKit

class ActivityViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Activity Details 🚶‍♂️")
        setupActivityMetrics()
    }
    
    // --- ADD THE STATE OF MIND UI ELEMENTS ---
        var moodTextField: UITextField!  // For mood input
        var aiResponseLabel: UILabel!    // To display AI response
    
    func setupBackground() {
           let gradientLayer = CAGradientLayer()
           gradientLayer.colors = [UIColor.black.cgColor, UIColor.red.cgColor, UIColor.black.cgColor]
           gradientLayer.locations = [0.0, 0.5, 1.0]
           gradientLayer.frame = view.bounds
           view.layer.insertSublayer(gradientLayer, at: 0)
       }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupActivityMetrics() {
        let exerciseMinutes = 66
          let exerciseDetails: String
        
        

          
          if unitPreference == .metric {
              exerciseDetails = "\(exerciseMinutes) minutes"
          } else {
              exerciseDetails = formatTimeAsDigitalClock(minutes: exerciseMinutes, seconds: 43, milliseconds: 32)
          }
        let caloriesBurned = unitPreference == .metric ? "221 kcal" : "0,221 kcal"
          let metrics = [
              ("🔥 Calories Burned", caloriesBurned, " "),
              ("🏋️‍♀️ Exercise Minutes", exerciseDetails, " "),
              ("👣 Steps", "12,106", "steps"),
              ("🚶‍♂️ Walking Distance", unitPreference == .metric ? "12 km" : "7.5 miles", "")
          ]
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }
    
       func formatTimeAsDigitalClock(minutes: Int, seconds: Int, milliseconds: Int) -> String {
           return String(format: "%02d:%02d:%02d", minutes, seconds, milliseconds)
       }
    
    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}

class SleepViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Sleep Details 🛌")
        setupSleepMetrics()
    }
    
    func setupBackground() {
            let gradientLayer = CAGradientLayer()
            gradientLayer.colors = [UIColor.black.cgColor, UIColor.blue.cgColor, UIColor.black.cgColor]
            gradientLayer.locations = [0.0, 0.5, 1.0]
            gradientLayer.frame = view.bounds
            view.layer.insertSublayer(gradientLayer, at: 0)
        }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupSleepMetrics() {
        let metrics = [
            ("🛌 Hours Slept", "8", "hours"),
            ("🌙 Hours Awake", "2", "hours")
        ]
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }
    
    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}
import UIKit



import UIKit

class StateOfMindViewController: UIViewController, UITextFieldDelegate {
    var unitPreference: UnitPreference = .metric
    var onStateOfMindUpdate: ((String) -> Void)?  // Closure to pass updated state of mind
    
    // UI Elements
    var moodTextField: UITextField!
    var aiResponseLabel: UILabel!
    var submitButton: UIButton!  // This will replace the label and act as a button
  

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "State of Mind Details 😊")
        setupStateOfMindMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.yellow.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupStateOfMindMetrics() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        // Create the mood input text field only in this view
        moodTextField = UITextField()
        moodTextField.placeholder = "How are you feeling today?"  // Show the prompt here
        moodTextField.borderStyle = .roundedRect
        moodTextField.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        moodTextField.translatesAutoresizingMaskIntoConstraints = false
        moodTextField.delegate = self
        stackView.addArrangedSubview(moodTextField)
        
        submitButton = UIButton(type: .system)
        submitButton.setTitle("Submit", for: .normal)
        submitButton.backgroundColor = UIColor.systemBlue
        submitButton.setTitleColor(.white, for: .normal)
        submitButton.layer.cornerRadius = 10
        submitButton.layer.borderWidth = 1
        submitButton.layer.borderColor = UIColor.white.cgColor
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.addTarget(self, action: #selector(chatWithAI), for: .touchUpInside)
        stackView.addArrangedSubview(submitButton)
        
        // Create and add the AI response label (initially hidden)
        aiResponseLabel = UILabel()
        aiResponseLabel.text = "ChatGPT will respond here."
        aiResponseLabel.numberOfLines = 0
        aiResponseLabel.font = UIFont(name: "TimesNewRomanPS-BoldMT", size: 22)
        aiResponseLabel.isHidden = false
        aiResponseLabel.translatesAutoresizingMaskIntoConstraints = false
        stackView.addArrangedSubview(aiResponseLabel)
    }


    
    // --- FUNCTION TO HANDLE AI INTERACTION ---
    @objc func chatWithAI() {
        let mood = moodTextField.text ?? ""
        if mood.isEmpty {
            aiResponseLabel.text = "Please enter your mood!"
            aiResponseLabel.isHidden = false
        } else {
            aiResponseLabel.isHidden = true
            fetchAIResponse(for: mood)
            
            onStateOfMindUpdate?(mood)  // Pass the updated mood back to the main page
        }
    }

    // --- FUNCTION TO FETCH AI RESPONSE ---
    func fetchAIResponse(for mood: String) {
        let apiKey = "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 "  // Ensure you're using a valid API key
        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        
        let messages: [[String: String]] = [
            ["role": "system", "content": "You are a helpful assistant."],
            ["role": "user", "content": "The user is feeling \(mood). Respond in a supportive and friendly way."]
        ]
        
        let requestBody: [String: Any] = [
            "model": "gpt-3.5-turbo",
            "messages": messages,
            "max_tokens": 100
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: requestBody)
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.aiResponseLabel.text = "Error: \(error.localizedDescription)"
                    self.aiResponseLabel.isHidden = false
                }
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    self.aiResponseLabel.text = "No data received"
                    self.aiResponseLabel.isHidden = false
                }
                print("No data received")
                return
            }
            
            // Debugging the raw response
            if let rawResponse = String(data: data, encoding: .utf8) {
                print("Raw Response: \(rawResponse)")
            }
            
            do {
                let response = try JSONDecoder().decode(ChatAIResponse.self, from: data)
                DispatchQueue.main.async {
                    self.aiResponseLabel.text = response.choices.first?.message.content.trimmingCharacters(in: .whitespacesAndNewlines)
                    self.aiResponseLabel.isHidden = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.aiResponseLabel.text = "Error decoding response"
                    self.aiResponseLabel.isHidden = false
                }
                print("Error decoding response: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }

    struct ChatAIResponse: Codable {
        let choices: [Choice]
    }

    struct Choice: Codable {
        let message: Message
    }

    struct Message: Codable {
        let content: String
    }
}





    
    func createMetricCard(title: String, value: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
    

import UIKit

class WorkoutsViewController: UIViewController {
    var unitPreference: UnitPreference = .metric 
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Workout Details 💪")
        setupWorkoutMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.orange.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupWorkoutMetrics() {
        let workoutMinutes = 66
            let workoutDetails: String

            if unitPreference == .metric {
                workoutDetails = "\(workoutMinutes) minutes"
            } else {
                workoutDetails = formatTimeAsDigitalClock(minutes: workoutMinutes, seconds: 43, milliseconds: 32)
            }
        let metrics = [
                 ("⏱ Exercise Time", workoutDetails, ""),
                 ("🏋️‍♂️ Weight Lifted", unitPreference == .metric ? "50 kg" : "110 lbs", ""),
                 ("🚴‍♂️ Distance Covered", unitPreference == .metric ? "12 km" : "7.5 miles", "")
             ]
        
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }
    func formatTimeAsDigitalClock(minutes: Int, seconds: Int, milliseconds: Int) -> String {
          return String(format: "%02d:%02d:%02d", minutes, seconds, milliseconds)
      }
    
    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }



    
}


class DietViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Diet Details 🍽")
        setupDietMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.green.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupDietMetrics() {
        // Create a scroll view to enable scrolling
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        
        // Add content view inside the scroll view to hold all metrics
        let contentView = UIView()
        contentView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentView)
        
        // Set scroll view constraints to fill the view
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // Set content view constraints to the scroll view
        NSLayoutConstraint.activate([
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
        
        // Now, create the stack view inside the content view
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stackView)
        
        // Set stack view constraints
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: contentView.topAnchor),
            stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
        
        let dietMetrics = [
            ("🍽 Daily Calorie Intake", "\(1500) kcal", ""),
            ("🍗 Protein Intake", "\(120) grams", ""),
            ("🍞 Carbohydrate Intake", "\(200) grams", ""),
            ("🥑 Fat Intake", "\(60) grams", ""),
            ("🥗 Recommended Diet", "Low Carb Diet", "")
        ]
        
        for metric in dietMetrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }

    
    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}

class O2ViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Blood Oxygen Details 🫁")
        setupBloodOxygenMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.blue.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupBloodOxygenMetrics() {
        let bloodOxygenMetrics = [
            ("🫁 Blood Oxygen Level", "\(98)%", ""),
            ("🫀 Resting Heart Rate", "\(60) BPM", "")
        ]
        
        addMetricsToView(bloodOxygenMetrics)
    }

    func addMetricsToView(_ metrics: [(String, String, String)]) {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }

    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}
class MedsViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Medicine Details 💊")
        setupMedicineMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.purple.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupMedicineMetrics() {
        let medicineMetrics = [
            ("💊 Medicine Taken", "Aspirin", ""),
            ("💧 Dosage", "\(100) mg", ""),
            ("🕒 Next Dose", "8:00 AM", "")
        ]
        
        addMetricsToView(medicineMetrics)
    }
    
    func addMetricsToView(_ metrics: [(String, String, String)]) {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }
    
    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}
class FlightsViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Flights Climbed Details 🛗")
        setupFlightsClimbedMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.orange.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupFlightsClimbedMetrics() {
        let flightsMetrics = [
            ("🛗 Flights Climbed", "\(10)", "flights"),
            ("🕒 Time Taken", "12 minutes", "")
        ]
        
        addMetricsToView(flightsMetrics)
    }
    
    func addMetricsToView(_ metrics: [(String, String, String)]) {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }

    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}
class VO2MaxViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "VO2 Max Details 🏃‍♂️")
        setupVO2MaxMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.red.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupVO2MaxMetrics() {
        let vo2MaxMetrics = [
            ("🏃‍♂️ VO2 Max", "\(40)", "mL/kg/min")
        ]
        
        addMetricsToView(vo2MaxMetrics)
    }
    
    func addMetricsToView(_ metrics: [(String, String, String)]) {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }

    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}
class AHRViewController: UIViewController {
    var unitPreference: UnitPreference = .metric
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupHeader(with: "Average Heart Rate Details ❤️")
        setupHeartRateMetrics()
    }
    
    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.red.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setupHeader(with text: String) {
        let headerLabel = UILabel()
        headerLabel.text = text
        headerLabel.font = UIFont.systemFont(ofSize: 28, weight: .bold)
        headerLabel.textColor = .white
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerLabel)
        
        NSLayoutConstraint.activate([
            headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupHeartRateMetrics() {
        let heartRateMetrics = [
            ("❤️ Average Heart Rate", "\(72) BPM", ""),
            ("💤 Resting Heart Rate", "\(60) BPM", ""),
            ("🚶‍♂️ Walking Heart Rate", "\(90) BPM", "")
        ]
        
        addMetricsToView(heartRateMetrics)
    }

    func addMetricsToView(_ metrics: [(String, String, String)]) {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        for metric in metrics {
            let card = createMetricCard(title: metric.0, value: metric.1, unit: metric.2)
            stackView.addArrangedSubview(card)
        }
    }

    func createMetricCard(title: String, value: String, unit: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        valueLabel.textColor = .black
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(valueLabel)
        
        let unitLabel = UILabel()
        unitLabel.text = unit
        unitLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        unitLabel.textColor = .gray
        unitLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(unitLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            valueLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            
            unitLabel.leadingAnchor.constraint(equalTo: valueLabel.trailingAnchor, constant: 4),
            unitLabel.bottomAnchor.constraint(equalTo: valueLabel.bottomAnchor),
            
            cardView.heightAnchor.constraint(equalToConstant: 100)
        ])
        
        return cardView
    }
}


