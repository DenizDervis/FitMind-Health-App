import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

        func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
            
            guard let windowScene = (scene as? UIWindowScene) else { return }
            
            // Create a UIWindow
            window = UIWindow(windowScene: windowScene)
            
            // Create the root view controller
            let mainVC = ViewController()
            
            // Embed the root view controller in a navigation controller
            let navigationController = UINavigationController(rootViewController: mainVC)
            
            // Set the root view controller of the window to be the navigation controller
            window?.rootViewController = navigationController
            
            // Make the window visible
            window?.makeKeyAndVisible()
        }
}
