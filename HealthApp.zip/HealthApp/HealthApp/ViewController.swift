import UIKit

enum UnitPreference {
    case metric
    case imperial
}

class ViewController: UIViewController {

    var unitPreference: UnitPreference = .metric

    // Store interaction counts and interaction timestamps for each feature
    var userInteractionData: [String: [String: Any]] = [
        "Activity": ["count": 0, "interactionTimestamps": [Date]()],
        "Sleep": ["count": 0, "interactionTimestamps": [Date]()],
        "Workouts": ["count": 0, "interactionTimestamps": [Date]()],
        "State of Mind": ["count": 0, "interactionTimestamps": [Date]()],
        "Diet": ["count": 0, "interactionTimestamps": [Date]()],
        "Average Heart Rate": ["count": 0, "interactionTimestamps": [Date]()],
        "Medicine": ["count": 0, "interactionTimestamps": [Date]()],
        "Flights Climbed": ["count": 0, "interactionTimestamps": [Date]()],
        "VO2 Max": ["count": 0, "interactionTimestamps": [Date]()],
        "Blood Oxygen": ["count": 0, "interactionTimestamps": [Date]()],
    ]

    var timeSpentData: [String: TimeInterval] = [
        "Activity": 0,
        "Sleep": 0,
        "Workouts": 0,
        "State of Mind": 0,
        "Diet": 0,
        "Average Heart Rate": 0,
        "Medicine": 0,
        "Flights Climbed": 0,
        "VO2 Max": 0,
        "Blood Oxygen": 0
    ]

    var startTime: Date?
    var currentFeature: String?  // Track which feature is currently active
    var currentUserEmail: String = ""  // Unique identifier for each user
    var currentStateOfMind: String = " "

    override func viewDidLoad() {
        super.viewDidLoad()

        loadCurrentUser()
        NotificationCenter.default.addObserver(self, selector: #selector(saveUserInteractionData), name: UIApplication.willTerminateNotification, object: nil)
        loadUserInteractionData()

        setupBackground()
        setupStateOfMindLabel()  // Add the State of Mind label to the main page
      

        let headlineLabel = UILabel()
        headlineLabel.text = "FitMind"
        headlineLabel.font = UIFont.systemFont(ofSize: 36, weight: .bold)
        headlineLabel.textColor = .white
        headlineLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headlineLabel)

        NSLayoutConstraint.activate([
            headlineLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            headlineLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        setupProfileButton()

       // navigationItem.rightBarButtonItem = UIBarButtonItem(title: "↔️ Switch Units", style: .plain, target: self, action: #selector(toggleUnitPreference))
        navigationItem.rightBarButtonItem?.tintColor = .white

        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        let contentView = UIView()
        contentView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: headlineLabel.bottomAnchor, constant: 16),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
        let sortedFeatures = userInteractionData.sorted { ($0.value["count"] as? Int ?? 0) > ($1.value["count"] as? Int ?? 0) }

        var lastView: UIView? = nil

        for (featureName, _) in sortedFeatures {
            let feature: (String, String, Selector, String)
            switch featureName {
            case "Activity":
                feature = ("Activity", formatActivity(), #selector(navigateToActivity), "flame.fill")
            case "Sleep":
                feature = ("Sleep", formatSleep(), #selector(navigateToSleep), "bed.double.fill")
            case "Workouts":
                feature = ("Workouts", formatWorkouts(), #selector(navigateToWorkouts), "figure.walk")
            case "State of Mind":
                feature = ("State of Mind", "How are you feeling today?", #selector(navigateToStateOfMind), "face.smiling.fill")
            case "Diet":
                feature = ("Diet", formatDiet(), #selector(navigateToDiet), "flame.fill")
            case "Average Heart Rate":
                feature = ("Average Heart Rate", formatHR(), #selector(navigateToHR), "heart.fill")
            case "Medicine":
                feature = ("Medicine", formatMeds(), #selector(navigateToMeds), "pills.fill")
            case "Flights Climbed":
                feature = ("Flights Climbed", formatFlights(), #selector(navigateToFlights), "figure.stairs")
            case "VO2 Max":
                feature = ("VO2 Max", formatVO2(), #selector(navigateToVO2), "lungs.fill")
            case "Blood Oxygen":
                feature = ("Blood Oxygen", formatBloodO2(), #selector(navigateToO2), "lungs.fill")
            default:
                feature = ("Unknown", "", #selector(navigateToActivity), "questionmark.circle")
            }

            let cardView = createCardView(title: feature.0, detail: feature.1, iconName: feature.3)
            contentView.addSubview(cardView)

            let tapGesture = UITapGestureRecognizer(target: self, action: feature.2)
            cardView.addGestureRecognizer(tapGesture)
            cardView.isUserInteractionEnabled = true

            NSLayoutConstraint.activate([
                cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
                cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
                cardView.heightAnchor.constraint(equalToConstant: 120),
                cardView.topAnchor.constraint(equalTo: lastView?.bottomAnchor ?? contentView.topAnchor, constant: 16)
            ])

            lastView = cardView
        }
        lastView?.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20).isActive = true

    }

    func setupStateOfMindLabel() {
        let stateOfMindLabel = UILabel()
        stateOfMindLabel.tag = 1001  // Tag to easily identify the label later

        // Only show the updated state of mind on the main page
        stateOfMindLabel.text = currentStateOfMind.isEmpty ? "A Pleasant Day" : currentStateOfMind
        stateOfMindLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        stateOfMindLabel.textColor = .white
        stateOfMindLabel.textAlignment = .center
        stateOfMindLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stateOfMindLabel)

        NSLayoutConstraint.activate([
            stateOfMindLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            stateOfMindLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        // Add a tap gesture recognizer to navigate to the State of Mind details
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(navigateToStateOfMind))
        stateOfMindLabel.isUserInteractionEnabled = true
        stateOfMindLabel.addGestureRecognizer(tapGesture)
    }


    @objc func navigateToActivity() {
        logUserInteraction(for: "Activity")
        let activityVC = ActivityViewController()
        activityVC.unitPreference = unitPreference
        startTrackingTime(for: "Activity")  // Start tracking time for the Activity feature
        navigationController?.pushViewController(activityVC, animated: true)
    }

    @objc func navigateToSleep() {
        logUserInteraction(for: "Sleep")
        let sleepVC = SleepViewController()
        sleepVC.unitPreference = unitPreference
        startTrackingTime(for: "Sleep")  // Start tracking time for the Sleep feature
        navigationController?.pushViewController(sleepVC, animated: true)
    }

    @objc func navigateToStateOfMind() {
        logUserInteraction(for: "State of Mind")
        let stateOfMindVC = StateOfMindViewController()
        stateOfMindVC.unitPreference = unitPreference

        stateOfMindVC.onStateOfMindUpdate = { [weak self] updatedMood in
            self?.currentStateOfMind = updatedMood  // Update the state of mind
           
        }

        navigationController?.pushViewController(stateOfMindVC, animated: true)
    }
  
   
   

 
    

    @objc func navigateToWorkouts() {
        logUserInteraction(for: "Workouts")
        let workoutsVC = WorkoutsViewController()
        workoutsVC.unitPreference = unitPreference
        startTrackingTime(for: "Workouts")  // Start tracking time for the Workouts feature
        navigationController?.pushViewController(workoutsVC, animated: true)
    }

    @objc func navigateToDiet() {
        logUserInteraction(for: "Diet")
        let dietVC = DietViewController()
        dietVC.unitPreference = unitPreference
        startTrackingTime(for: "Diet")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(dietVC, animated: true)
    }
    @objc func navigateToHR() {
        logUserInteraction(for: "Average Heart Rate")
        let HRVC = AHRViewController()
        HRVC.unitPreference = unitPreference
        startTrackingTime(for: "Average Heart Rate")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(HRVC, animated: true)
    }
    @objc func navigateToMeds() {
        logUserInteraction(for: "Medicine")
        let MedsVC = MedsViewController()
        MedsVC.unitPreference = unitPreference
        startTrackingTime(for: "Medicine")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(MedsVC, animated: true)
    }
    @objc func navigateToFlights() {
        logUserInteraction(for: "Flights Climbed")
        let FlightsVC = FlightsViewController()
        FlightsVC.unitPreference = unitPreference
        startTrackingTime(for: "Flights Climbed")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(FlightsVC, animated: true)
    }
    @objc func navigateToVO2() {
        logUserInteraction(for: "VO2 Max")
        let VO2MaxVC = VO2MaxViewController()
        VO2MaxVC.unitPreference = unitPreference
        startTrackingTime(for: "VO2 Max")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(VO2MaxVC, animated: true)
    }
    @objc func navigateToO2() {
        logUserInteraction(for: "Blood Oxygen")
        let O2VC = O2ViewController()
        O2VC.unitPreference = unitPreference
        startTrackingTime(for: "Blood Oxygen")  // Start tracking time for the Diet feature
        navigationController?.pushViewController(O2VC, animated: true)
    }
    
    // Sort features by interaction count and create cards
        func setupCards(in contentView: UIView) {
            let sortedFeatures = userInteractionData.sorted { ($0.value["count"] as? Int ?? 0) > ($1.value["count"] as? Int ?? 0) }

            var lastView: UIView? = nil
            for feature in sortedFeatures {
                let cardView = createCardView(for: feature.key)
                contentView.addSubview(cardView)
                
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleCardTap(_:)))
                cardView.addGestureRecognizer(tapGesture)
                cardView.isUserInteractionEnabled = true
                
                NSLayoutConstraint.activate([
                    cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
                    cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
                    cardView.heightAnchor.constraint(equalToConstant: 120),
                    cardView.topAnchor.constraint(equalTo: lastView?.bottomAnchor ?? contentView.topAnchor, constant: 16)
                ])
                lastView = cardView
            }

            lastView?.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20).isActive = true
        }

        @objc func handleCardTap(_ sender: UITapGestureRecognizer) {
            guard let tappedCard = sender.view else { return }
            if let featureName = tappedCard.accessibilityIdentifier {
                logUserInteraction(for: featureName)
            }
            reloadCards()
        }

        // Reload cards to reflect new order based on interaction
        func reloadCards() {
            for subview in view.subviews {
                subview.removeFromSuperview()
            }
            viewDidLoad()
        }
    // Create a feature card view
    func createCardView(for feature: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false
        cardView.accessibilityIdentifier = feature
        
        let titleLabel = UILabel()
        titleLabel.text = feature
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .orange
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16)
        ])
        
        return cardView
    }


    func logUserInteraction(for feature: String) {
        let currentTime = Date()
        currentFeature = feature
        startTime = currentTime  // Track start time for time spent

        var featureData = userInteractionData[feature] ?? [:]
        featureData["count"] = (featureData["count"] as? Int ?? 0) + 1
        var timestamps = featureData["interactionTimestamps"] as? [Date] ?? []
        timestamps.append(currentTime)
        featureData["interactionTimestamps"] = timestamps

        userInteractionData[feature] = featureData

        saveUserInteractionData()
    }

    func startTrackingTime(for feature: String) {
        currentFeature = feature
        startTime = Date()  // Set the start time when navigating to a feature
    }

    func calculateTimeSpent() {
        guard let feature = currentFeature, let startTime = startTime else { return }
        let endTime = Date()
        let timeInterval = endTime.timeIntervalSince(startTime)
        timeSpentData[feature, default: 0] += timeInterval
        saveUserInteractionData()  // Save the data each time we update it
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        calculateTimeSpent()  // Calculate the time spent before leaving the screen
    }

    @objc func saveUserInteractionData() {
        let userDefaults = UserDefaults.standard
        userDefaults.set(userInteractionData, forKey: "userInteractionData_\(currentUserEmail)")
        userDefaults.set(timeSpentData, forKey: "timeSpentData_\(currentUserEmail)")
    }

    func loadUserInteractionData() {
        let userDefaults = UserDefaults.standard
        let defaultFeatures = defaultUserInteractionData() // Get default features for comparison

        // Try to load saved user interaction data for the current user
        if let savedData = userDefaults.dictionary(forKey: "userInteractionData_\(currentUserEmail)") as? [String: [String: Any]] {
            // Ensure all features are initialized for the user
            userInteractionData = defaultFeatures.merging(savedData) { (_, saved) in saved }
        } else {
            // If no data exists for this user, use default interaction data
            userInteractionData = defaultFeatures
        }

        // Load saved time spent data for the user
        if let savedTimeSpent = userDefaults.dictionary(forKey: "timeSpentData_\(currentUserEmail)") as? [String: TimeInterval] {
            timeSpentData = savedTimeSpent
        } else {
            // Initialize time spent data with default values
            timeSpentData = defaultTimeSpentData()
        }
    }


    func loadCurrentUser() {
        let userDefaults = UserDefaults.standard
        currentUserEmail = userDefaults.string(forKey: "currentUserEmail") ?? ""
    }
    
    // Default user interaction data for all features
    func defaultUserInteractionData() -> [String: [String: Any]] {
        return [
            "Activity": ["count": 0, "interactionTimestamps": [Date]()],
            "Sleep": ["count": 0, "interactionTimestamps": [Date]()],
            "Workouts": ["count": 0, "interactionTimestamps": [Date]()],
            "State of Mind": ["count": 0, "interactionTimestamps": [Date]()],
            "Diet": ["count": 0, "interactionTimestamps": [Date]()],
            "Average Heart Rate": ["count": 0, "interactionTimestamps": [Date]()],
            "Medicine": ["count": 0, "interactionTimestamps": [Date]()],
            "Flights Climbed": ["count": 0, "interactionTimestamps": [Date]()],
            "VO2 Max": ["count": 0, "interactionTimestamps": [Date]()],
            "Blood Oxygen": ["count": 0, "interactionTimestamps": [Date]()]
        ]
    }

    // Default time spent data for all features
    func defaultTimeSpentData() -> [String: TimeInterval] {
        return [
            "Activity": 0,
            "Sleep": 0,
            "Workouts": 0,
            "State of Mind": 0,
            "Diet": 0,
            "Average Heart Rate": 0,
            "Medicine": 0,
            "Flights Climbed": 0,
            "VO2 Max": 0,
            "Blood Oxygen": 0
        ]
    }


    func formatActivity() -> String {
        let exerciseMinutes = 66
        let exerciseDetails: String
        if unitPreference == .metric {
            exerciseDetails = "\(exerciseMinutes) minutes"
        } else {
            exerciseDetails = formatTimeAsDigitalClock(minutes: exerciseMinutes, seconds: 43, milliseconds: 32)
        }
        return "Move: 221 kcal\nExercise: \(exerciseDetails)\nStand: 1 hr"
    }

    func formatSleep() -> String {
        return "8 hrs asleep, 2 hrs awake"
    }

    func formatWorkouts() -> String {
        return "1 hr, 12.1 km"
    }

    func formatDiet() -> String {
        return "bunlari bunlari yedin"
    }
    func formatHR() -> String {
        return "You have a 170 BPM Heart Rate"
    }
    func formatMeds() -> String {
        return "Dont forget your meds today"
    }
    func formatFlights() -> String {
        return "Flights that are climbed is 4"
    }
    func formatVO2() -> String {
        return "Your VO2 Max is below average"
    }
    func formatBloodO2() -> String {
        return "Your oxygen level in your blood is 97%"
    }

    func formatTimeAsDigitalClock(minutes: Int, seconds: Int, milliseconds: Int) -> String {
        return String(format: "%02d:%02d:%02d", minutes, seconds, milliseconds)
    }

    func createCardView(title: String, detail: String, iconName: String) -> UIView {
        let cardView = UIView()
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOpacity = 0.1
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 5
        cardView.translatesAutoresizingMaskIntoConstraints = false

        let icon = UIImageView(image: UIImage(systemName: iconName))
        icon.tintColor = .orange
        icon.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(icon)

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .black
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(titleLabel)

        let detailLabel = UILabel()
        detailLabel.text = detail
        detailLabel.font = UIFont.systemFont(ofSize: 16)
        detailLabel.textColor = .gray
        detailLabel.numberOfLines = 0
        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        cardView.addSubview(detailLabel)

        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 16),
            icon.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            icon.widthAnchor.constraint(equalToConstant: 40),
            icon.heightAnchor.constraint(equalToConstant: 40),

            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -16),

            detailLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            detailLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            detailLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor)
        ])

        return cardView
    }

    @objc func toggleUnitPreference() {
        if unitPreference == .metric {
            changeUnitPreference(to: .imperial)
        } else {
            changeUnitPreference(to: .metric)
        }
    }

    func changeUnitPreference(to preference: UnitPreference) {
        self.unitPreference = preference
        viewDidLoad() // Refresh UI
    }

    func setupBackground() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.black.cgColor, UIColor.orange.cgColor, UIColor.black.cgColor]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.frame = view.bounds
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    func setupProfileButton() {
        let profileButton = UIBarButtonItem(title: "👤 Profile", style: .plain, target: self, action: #selector(navigateToProfile))
        navigationItem.leftBarButtonItem = profileButton
        navigationItem.leftBarButtonItem?.tintColor = .white
    }

    @objc func navigateToProfile() {
        let profileVC = ProfileViewController()
        navigationController?.pushViewController(profileVC, animated: true)
    }


    
    // Export the collected data as a CSV file
    func exportUserInteractionDataToFile() {
        let fileName = "user_interaction_data.csv"
        let path = getDocumentsDirectory().appendingPathComponent(fileName)
        let csvData = generateCSVString()

        do {
            try csvData.write(to: path, atomically: true, encoding: .utf8)
            print("Data exported to: \(path)") // Print the file path to the console

            // Show an alert with the file path to the user
            let alert = UIAlertController(title: "Data Exported", message: "CSV file saved to: \(path)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true, completion: nil)

        } catch {
            print("Failed to export data: \(error)")

            // Show an error alert
            let alert = UIAlertController(title: "Error", message: "Failed to export data: \(error)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true, completion: nil)
        }
    }

    // Helper to generate the CSV data as a string
    func generateCSVString() -> String {
        var csvData = "Feature,InteractionCount,TimeSpent(seconds)\n"
        for (feature, data) in userInteractionData {
            let count = data["count"] as? Int ?? 0
            let timeSpent = timeSpentData[feature] ?? 0
            csvData += "\(feature),\(count),\(timeSpent)\n"
        }
        return csvData
    }

    // Helper function to get the document directory
    func getDocumentsDirectory() -> URL {
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
}
